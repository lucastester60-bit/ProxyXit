package com.proxy.xit

object XitConfig {
    var isEspBoxEnabled: Boolean = false
    var isAimLockEnabled: Boolean = false
    var aimFov: Int = 30
    var boxColor: String = "#FF0000"
}
