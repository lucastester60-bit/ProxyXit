package com.proxy.xit

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val button = Button(this).apply {
            text = "Ativar Overlay / Mod Menu"
            setOnClickListener {
                checkOverlayPermission()
            }
        }
        setContentView(button)
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, 1234)
            Toast.makeText(this, "Permita sobreposição para exibir o menu", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Permissão já concedida! Iniciando...", Toast.LENGTH_SHORT).show()
        }
    }
}
